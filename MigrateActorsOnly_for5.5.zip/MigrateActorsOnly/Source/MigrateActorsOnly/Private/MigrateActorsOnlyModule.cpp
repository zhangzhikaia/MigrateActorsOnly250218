// Copyright lurongjiu. All Rights Reserved.Intended published in 2025.

#include "MigrateActorsOnlyModule.h"

#include "ActorTreeItem.h"
//
//#include "AssetToolsModule.h"
//#include "ActorFolder.h"
#include "AssetToolsModule.h"
//#include "ContentBrowserDataMenuContexts.h"
#include "ContentBrowserMenuContexts.h"
#include "LevelEditor.h"
#include "MigrateActorsUtils.h"

#include "SSceneOutliner.h"
#include "SceneOutlinerMenuContext.h"
//#include "SLevelViewport.h"

#include "FileHelpers.h"
#include "MigrateActorsIconStyle.h"
#include "ToolMenu.h"
#include "ToolMenus.h"

#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

//#include "Kismet/KismetSystemLibrary.h"

#define LOCTEXT_NAMESPACE "FMigrateActorsOnlyModule"

void FMigrateActorsOnlyModule::StartupModule()
{
	FMigrateActorsIconStyle::InitializeIcons();
	
	RegisterToolBarRecorderDeleteMenu();
	RegisterOutlinerContextMenuExtend_MigrateActors();
#if BETA
	RegisterAssetContextMenu_LevelSynFromContent();
	RegisterOnMapChanged();
#endif
}

void FMigrateActorsOnlyModule::ShutdownModule()
{
	FMigrateActorsIconStyle::ShutDownIcons();
	
#if BETA
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));

	if(OnMapChangedHandle.IsValid())
	{
		LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle);
		OnMapChangedHandle.Reset();
	}
#endif
}

void FMigrateActorsOnlyModule::RegisterToolBarRecorderDeleteMenu()
{
	FToolMenuOwnerScoped OwnerScoped(this);
	
	UToolMenu* ToolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar.PlayToolBar");
	
	FToolMenuSection& Section = ToolbarMenu->FindOrAddSection("RecorderDeleteList");
	
	Section.AddEntry(FToolMenuEntry::InitToolBarButton(
		FName("RecorderDeleteList"),
		FUIAction(FExecuteAction::CreateRaw( this, &FMigrateActorsOnlyModule::OnDeleteRecorderStateToggle),
					FCanExecuteAction::CreateLambda([](){return true;}),
					FGetActionCheckState::CreateLambda([this]()
					{
						return MigrateActorUtils::GetRecorderState()? ECheckBoxState::Checked : ECheckBoxState::Unchecked;
					})),
		LOCTEXT("RecorderDeleteList_Label", "RecorderDeleteList"),
		LOCTEXT("RecorderDeleteList_ToolTip", "Click \"Start\" to record all history of deleted actors. Click \"End\" to export the history to the content folder."),
		FSlateIcon(FMigrateActorsIconStyle::GetStyleSetName(),"RecorderStyle"),
		EUserInterfaceActionType::ToggleButton
		)
	);
}

void FMigrateActorsOnlyModule::OnDeleteRecorderStateToggle()
{
	if(!MigrateActorUtils::GetRecorderState())
	{
		//开始记录
		MigrateActorUtils::ClearLevelDeletedActorsList();
		
		if(GEngine==nullptr) return;
		if(!OnLevelActorDeleted.IsValid())
		{
			OnLevelActorDeleted = GEngine->OnLevelActorDeleted().AddLambda([](const AActor* ActorDeleted)
			{
				MigrateActorUtils::DeletedActorAddToList(ActorDeleted);
			});
		}
		
		FNotificationInfo Info(LOCTEXT("InfoRecorderStart", "The actor that is deleted will be recorded."));
		Info.FadeOutDuration = 5.f;
		FSlateNotificationManager::Get().AddNotification(Info);
	}
	else
	{
		//结束记录,导出s
		if(GEngine==nullptr) return;
		if(OnLevelActorDeleted.IsValid())
		{
			GEngine->OnLevelActorDeleted().Remove(OnLevelActorDeleted);
			OnLevelActorDeleted.Reset();
		}

		if(MigrateActorUtils::DeletedActorListAddToJson())
		{
			//弹窗提示保存dirt
			FEditorFileUtils::SaveDirtyPackages(true, true, true);
		}
		else
		{
			//当没有actors被删除时弹出， 有的话弹窗选路径
			FNotificationInfo Info(LOCTEXT("InfoRecorderEnd", "No deletion records have been migrated."));
			Info.FadeOutDuration = 5.f;
			FSlateNotificationManager::Get().AddNotification(Info);
		}
	}

	//最后再转换state， 如果先转换了，执行事件就反了
	MigrateActorUtils::ToggleRecorderState();
}

void FMigrateActorsOnlyModule::RegisterOutlinerContextMenuExtend_MigrateActors()
{
	static const FName DefaultContextBaseMenuName("SceneOutliner.DefaultContextMenuBase");
	
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(DefaultContextBaseMenuName);

	
	Menu->AddDynamicSection("MigrateActorsSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		const USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerItemOptions");
		Section.Label = LOCTEXT("ItemOptionsLabel", "Item Options");
		
		SelectedSceneOutliner = Context->SceneOutliner;
		
		/*only select actors*/
		if(Context->NumSelectedItems > 0 && Context->NumSelectedFolders == 0 && Context->NumWorldsSelected == 0)
		{
			ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"MigrateActors",
				LOCTEXT("Migrate", "Migrate..."),
				LOCTEXT("MigrateTooltip_Actors", "Copies all selected actors and their dependencies to another project."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "ContentBrowser.Migrate"),
				FUIAction( FExecuteAction::CreateRaw( this, &FMigrateActorsOnlyModule::OutlinerActorExecuteMigrate ) )
				);
		}
		else
		{
			ExecuteItems.Empty();
		}
	}));
}

void FMigrateActorsOnlyModule::OutlinerActorExecuteMigrate()
{
	//外部包路径
	TArray<FName> ExternalPackageNames;
	//actor全部依赖项
	TArray<FName> AssetPackageNames;
	//是否提示需要开启UsingExternal
	bool NeedUsingExternal = false;
	//需要开启UsingExternal的关卡名
	FString NeedUsingExternalLevel;
	//是否提示不能为临时关卡
	bool NoTempMap = false;
	
	
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(const FActorTreeItem* SelectedActor = SelectedItem->CastTo<FActorTreeItem>())
		{
			//根据actor所在level判断而非持久关卡，固每个actor都要判断（是否开启了external actors）
			if(SelectedActor->Actor->GetLevel()->IsUsingExternalActors())
			{
				//来自临时关卡的actor不迁移,Template一定是临时关卡，先判断以节省性能.但启动引擎初始关卡不算做Template，固再次判断
				if(!SelectedActor->Actor->GetLevel()->IsTemplate() && !MigrateActorUtils::IsActorInTempMap(SelectedActor))
				{
					//1. 获取每个actor的依赖项，有些actor依赖项很多，有些则没有依赖项（引擎资产）
					MigrateActorUtils::GetActorsReferencedAssets(AssetPackageNames,SelectedActor->Actor);
					//2. 每个actor自己的文件
					ExternalPackageNames.AddUnique(FName(SelectedActor->Actor->GetExternalPackage()->GetName()));
					//3. 每个actor的文件夹
					MigrateActorUtils::AddActorsLocatedFoldersToList(ExternalPackageNames,SelectedActor->Actor);
				}
				else/*普通关卡开启UsingExternalActors不能是临时关卡， 但开放世界可能是， 为避免无响应导致疑惑，提示*/
				{
					NoTempMap = true;
					//actor处于开启了UsingExternalActors的临时关卡， 那么一定是大世界模板， 而大世界模板不允许子关卡，固所有actor都在模板关卡中，可以直接结束遍历了。
					break;
				}
			}
			else/*有关卡没开外部actors， 标记提醒*/
			{
				NeedUsingExternal = true;
				if(NeedUsingExternalLevel.IsEmpty())
				{
					NeedUsingExternalLevel = SelectedActor->Actor->GetLevel()->GetPackage()->GetName();
				}
			}
		}
	}

	
	//1.提示保存dirt，以使下一步不再提示 2.无需提示勾选（随机命名无法检阅 3.选择文件夹迁移 4.提示覆盖项或跳过
	FString DestinationPath; /*用于保存下一步选择的路径以及下下一步输入*/
	
	FMigrationOptions Options = FMigrationOptions();
	Options.bPrompt = true;

	if(ExternalPackageNames.Num()>0)
	{
		//只有在ExternalActors迁移成功才提示迁移资产, 否则不迁移资产
		//todo:改为获取迁移成功的ExternalActors的资产, 有放弃迁移的也放弃迁移资产
		if(MigrateActorUtils::MigrateExternalActors(ExternalPackageNames, DestinationPath, Options))
		{
			//选择是否迁移依赖项，
			if(AssetPackageNames.Num()>0)
			{
				FAssetToolsModule& AssetToolsModule = FModuleManager::Get().LoadModuleChecked<FAssetToolsModule>("AssetTools");
	
				AssetToolsModule.Get().MigratePackages( AssetPackageNames ,DestinationPath ,Options);
			}
		}
	}

	if(NoTempMap)
	{
		FMessageDialog::Open(EAppMsgType::Ok,
			LOCTEXT("MessageNoTempMap","Actors cannot be migrated from a temp level."),
			LOCTEXT("MessageTitle","Message"));
	}
	
	//如果有关卡没有开启， 提示， 但不执行操作。 提示一个关卡让用户检查
	if(NeedUsingExternal)
	{
		FText Message = FText::Format(
			LOCTEXT("MessageNeedUsingExternal","Need to enable the \"Use External Actors\" option in the World Settings - World - Advanced. The level named ({0}) is not enabled."),
			FText::FromString(NeedUsingExternalLevel));
		FMessageDialog::Open(EAppMsgType::Ok,Message,LOCTEXT("MessageTitle","Message"));
	}
}

#if BETA
void FMigrateActorsOnlyModule::RegisterAssetContextMenu_LevelSynFromContent()
{
	static const FName BaseMenuName("ContentBrowser.AssetContextMenu");
	
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(BaseMenuName);
	
	Menu->AddDynamicSection("LevelSynSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		UContentBrowserAssetContextMenuContext* Context = InMenu->FindContext<UContentBrowserAssetContextMenuContext>();
		if (!Context)
		{
			return;
		}
		
		FToolMenuSection& Section = InMenu->FindOrAddSection("LevelMigrateActorsOptions");
		Section.Label = LOCTEXT("LevelOptions", "Level Options");
		
		bool OnlyWorldInSelection = true;
		for(const FAssetData& Asset : Context->SelectedAssets)
		{
			if(Asset.GetClass()->GetName() != FString(TEXT("World")))
			{
				OnlyWorldInSelection = false;
				break;
			}
		}
		if(OnlyWorldInSelection)
		{
			ExecuteSelectedAssets = Context->SelectedAssets;
			
			Section.AddMenuEntry(
				"LevelSynFromContent",
				LOCTEXT("LevelSynFromContent", "Level Sync From Content"),
				LOCTEXT("MigrateTooltip_LevelSynFromContent", "Synchronize actors of the selected level from the target content."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "ContentBrowser.Migrate"),
				FUIAction( FExecuteAction::CreateRaw( this, &FMigrateActorsOnlyModule::LevelAssetExecuteSynFromContent ) )
				);
		}
		else
		{
			ExecuteSelectedAssets.Empty();
		}
		
		
	}));
}

void FMigrateActorsOnlyModule::LevelAssetExecuteSynFromContent()
{
	TMap<FString,ULevel*> OpenedLevels;
	
	if(CurrentWorld != nullptr)
	{
		for(ULevel* SubLevel : CurrentWorld->GetLevels())
		{
			if(!SubLevel->GetPackage()->GetName().StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
			{
				OpenedLevels.Add(SubLevel->GetPackage()->GetName(),SubLevel);
			}
		}
	}

	for(const FAssetData& LevelAsset : ExecuteSelectedAssets)
	{
		//@todo:如果关卡已开启， 获取其指针， 用指针操作内容
		if(const FString AssetPackageName = LevelAsset.PackageName.ToString();
			OpenedLevels.Num()>0 && OpenedLevels.Contains(AssetPackageName))
		{
			ULevel* LevelPointer = OpenedLevels.FindChecked(AssetPackageName);
			//OpenedLevels.FindChecked()
			//Debug::Print("levelopened,bu cao zuo");
			//@todo: 开启时同步方法 , 不行提示不能开启
			
		}
		else
		{
			if(const UWorld* World = Cast<UWorld>(LevelAsset.GetAsset()))
			{
				if(World->GetLevel(0)->IsUsingExternalActors())
				{
					MigrateActorUtils::SynFromContentWhenLevelClosed(AssetPackageName);
				}
				else
				{
					FNotificationInfo Info(LOCTEXT("InfoUseExternalActors", "Only levels with UseExternalActors enabled can be synchronized."));
					Info.FadeOutDuration = 5.f;
					FSlateNotificationManager::Get().AddNotification(Info);
				}
			}
		}
	}
}

void FMigrateActorsOnlyModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](const UWorld* World, const EMapChangeType MapChangeType)
	{

		switch (MapChangeType)
		{
		case EMapChangeType::LoadMap:
			CurrentWorld = (UWorld*)World;
			break;

		default:		
			break;
		}
	});
}
#endif

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FMigrateActorsOnlyModule, MigrateActorsOnly)