﻿// Copyright lurongjiu. All Rights Reserved.Intended published in 2025.

#include "MigrateActorsIconStyle.h"

#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyleMacros.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/StyleColors.h"
#include "Styling/SlateStyle.h"
#include "MigrateActorsUtils.h"

/*class FIconStyle*/
TSharedPtr<FSlateStyleSet> FMigrateActorsIconStyle::CreatedSlateStyleSet = nullptr;

void FMigrateActorsIconStyle::InitializeIcons()
{
	if(!CreatedSlateStyleSet.IsValid())
	{
		CreatedSlateStyleSet = CreateSlateStyleSet();
		FSlateStyleRegistry::RegisterSlateStyle(*CreatedSlateStyleSet);
	}
}

void FMigrateActorsIconStyle::ShutDownIcons()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*CreatedSlateStyleSet);
	ensure(CreatedSlateStyleSet.IsUnique());
	CreatedSlateStyleSet.Reset();
}

const ISlateStyle& FMigrateActorsIconStyle::Get()
{
	return *CreatedSlateStyleSet;
}

FName FMigrateActorsIconStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("MigrateActorsIconStyle"));
	return StyleSetName;
}

TSharedRef<FSlateStyleSet> FMigrateActorsIconStyle::CreateSlateStyleSet()
{

#define RootToContentDir CustomToolBarStyleSet->RootToContentDir
	
	TSharedRef<FSlateStyleSet> CustomToolBarStyleSet = MakeShareable(new FSlateStyleSet(GetStyleSetName()));

	CustomToolBarStyleSet->SetContentRoot(IPluginManager::Get().FindPlugin(TEXT("MigrateActorsOnly"))->GetBaseDir() /"Resources");
	
	const FVector2D Icon64X64(64.f,64.f);
#if BETA
	//CustomToolBarStyleSet->Set("RecorderStyle",new IMAGE_BRUSH("Recorder",Icon64X64));
	//CustomToolBarStyleSet->Set("RecorderStyle",new IMAGE_BRUSH("Stop",Icon64X64));
//todo: 一用checkbox就不显示图标， 看源码的播放键怎么做的
	//FCheckBoxStyle CheckBoxStyle = FCheckBoxStyle()
	//FButtonStyle x = FButtonStyle();
	//.SetCheckBoxType(ESlateCheckBoxType::ToggleButton)
	//.SetBackgroundImage(IMAGE_BRUSH("Recorder",Icon64X64));
	//.SetPadding(FMargin(10.f))
	/*设置未勾选状态三种样式*/
	//.SetUncheckedImage(IMAGE_BRUSH("Recorder",Icon64X64,FStyleColors::White))
	//.SetUncheckedHoveredImage(IMAGE_BRUSH("Recorder",Icon64X64,FStyleColors::Foreground))
	//.SetUncheckedPressedImage(IMAGE_BRUSH("Recorder",Icon64X64,FStyleColors::AccentBlack))
	/*设置勾选状态三种样式*/
	//.SetCheckedImage(IMAGE_BRUSH("Stop",Icon64X64,FStyleColors::White));
	//.SetCheckedHoveredImage(IMAGE_BRUSH("Stop",Icon64X64,FStyleColors::White25))
	//.SetCheckedPressedImage(IMAGE_BRUSH("Stop",Icon64X64,FStyleColors::Background));
#endif
	
	CustomToolBarStyleSet->Set("RecorderStyle",new IMAGE_BRUSH("Recorder",Icon64X64));
	
#undef RootToContentDir
	return CustomToolBarStyleSet;
}
