// Copyright lurongjiu 2025 All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "SceneOutlinerFwd.h"
#include "Modules/ModuleManager.h"

#include "MigrateActorsUtils.h"


class FMigrateActorsOnlyModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;


private:
	void RegisterToolBarRecorderDeleteMenu();

	void OnDeleteRecorderStateToggle();
	
	void RegisterOutlinerContextMenuExtend_MigrateActors();

	void OutlinerActorExecuteMigrate();

#if BETA
	void RegisterAssetContextMenu_LevelSynFromContent();

	void LevelAssetExecuteSynFromContent();
	/*When open/close/save map,update the saved data*/
	void RegisterOnMapChanged();
#endif
private:
	/*Current active SceneOutliner*/
	TWeakPtr<SSceneOutliner> SelectedSceneOutliner;
	/*Selected Items in current active SceneOutliner*/
	TArray<FSceneOutlinerTreeItemPtr> ExecuteItems;
	
	FDelegateHandle OnLevelActorDeleted;

#if BETA
	/*已选level资产*/
	TArray<FAssetData> ExecuteSelectedAssets;

	FDelegateHandle OnMapChangedHandle;

	UWorld* CurrentWorld = nullptr;
#endif
};
