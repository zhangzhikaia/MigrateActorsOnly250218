﻿// Copyright lurongjiu 2025 All Rights Reserved.

#include "MigrateActorsUtils.h"
#include "ActorTreeItem.h"

#include "FileHelpers.h"
#include "IAssetTools.h"

#include "DesktopPlatformModule.h"
#include "EditorDirectories.h"
#include "ActorFolder.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"

#include "Serialization/JsonSerializer.h"


#define LOCTEXT_NAMESPACE "FMigrateActorsOnlyUtils"

namespace MigrateActorsProperties
{
	static bool bIsRecording = false;

	//关卡 - actors
	static TMap< FString, TArray<FString> > LevelDeletedActorsList;
	
}

bool MigrateActorUtils::IsActorInTempMap(const AActor* Actor)
{
	return Actor->GetLevel()->GetPathName().StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive);
}

bool MigrateActorUtils::IsActorInTempMap(const FActorTreeItem* SelectedActor)
{
	return SelectedActor->Actor->GetLevel()->GetPathName().StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive);
}

bool MigrateActorUtils::MigrateExternalActors(const TArray<FName>& PackageNamesToMigrate, FString& DestinationPath, const FMigrationOptions& Options)
{
	// Packages must be saved for the migration to work
	const bool bPromptUserToSave = !FApp::IsUnattended() && Options.bPrompt;
	const bool bSaveMapPackages = true;
	const bool bSaveContentPackages = true;
	//提示保存dirt， 保存或不保存都会进行下一步，取消会终止下一步
	if (FEditorFileUtils::SaveDirtyPackages(bPromptUserToSave, bSaveMapPackages, bSaveContentPackages))
	{
		//打开窗口，选择content文件夹， 
		if(OpenSelectFolderDialog(DestinationPath, LOCTEXT("MigrateToFolderTitle", "Choose a destination Content folder").ToString()))
		{
			//将PackageNamesToMigrate迁移并保存path， 若终止，返回false
			if(MigrateMoveFile(PackageNamesToMigrate,DestinationPath))
			{
				return true;
			}
		}
	}
		
	return false;
}

bool MigrateActorUtils::OpenSelectFolderDialog(FString& OutFolderName, const FString& Title)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	if (ensure(DesktopPlatform))
		{
			const void* ParentWindowWindowHandle = FSlateApplication::Get().FindBestParentWindowHandleForDialogs(nullptr);
		
			//用于while， 若没选对content， 可重新弹窗， 知道选择完成或某处点击取消
			bool bFolderAccepted = false;
			while (!bFolderAccepted)
			{
				//弹窗让用户选择文件夹
				const bool bFolderSelected = DesktopPlatform->OpenDirectoryDialog(
					ParentWindowWindowHandle,
					Title,
					FEditorDirectories::Get().GetLastDirectory(ELastDirectory::GENERIC_EXPORT),
					OutFolderName
				);
				//用户点击取消， 结束全部操作
				if (!bFolderSelected)
				{
					return false;
				}

				FEditorDirectories::Get().SetLastDirectory(ELastDirectory::GENERIC_EXPORT, OutFolderName);
				FPaths::NormalizeFilename(OutFolderName);
				if (!OutFolderName.EndsWith(TEXT("/")))
				{
					OutFolderName += TEXT("/");
				}

				// Verify that it is a content folder
				if (!OutFolderName.EndsWith(TEXT("/Content/")))
				{
					//如果选择的不是content文件夹， 弹窗提示
					const FText Message = FText::Format(LOCTEXT("MigratePackages_NonContentFolder", "{0} does not appear to be a Content folder. Migrated content only work if placed in a Content folder. Select a Content folder."), FText::FromString(OutFolderName));
					EAppReturnType::Type Response = FMessageDialog::Open(EAppMsgType::OkCancel, Message);
					//在弹窗提示中， 点击确定， 重新弹出窗口让用户选择文件夹， 若点击取消， 不再弹出， 结束全部操作
					if (Response == EAppReturnType::Cancel)
					{
						return false;
					}

					continue;
				}
				
				//结束while
				bFolderAccepted = true;
			}
		}
		else
		{
			//报错，一般不出现
			// Not on a platform that supports desktop functionality
			FMessageDialog::Open(EAppMsgType::Ok, LOCTEXT("NoDesktopPlatform", "Error: This platform does not support a file dialog."));
			return false;
		}

	//"/"替换为"\"有效
	FPaths::NormalizeDirectoryName(OutFolderName);
	OutFolderName.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
	
	return true;
}

bool MigrateActorUtils::MigrateMoveFile(const TArray<FName>& PackageNamesToMigrate, const FString& DestinationPath)
{
	bool HasFileMoved = false;

	IFileManager& FileManager = IFileManager::Get();

	TMap<FString,FString> ExistingPackages;

	//获取项目的content路径
	const FString AbsoluteProjectContentDir = FileManager.ConvertToAbsolutePathForExternalAppForRead(*FPaths::ProjectContentDir());
	
	for(FName PackageName : PackageNamesToMigrate)
	{
		FString RelativePath = PackageName.ToString();

		//添加后缀
		RelativePath += ".uasset";
		//实际路径没有/Game,content内的完整路径， 保存下来
		RelativePath.RemoveFromStart("/Game/");
		
		//和项目content组合就是资产的真实路径
		FString PackageFullPath = FPaths::Combine(AbsoluteProjectContentDir,RelativePath);
		
		FPaths::NormalizeFilename(PackageFullPath);

		//文件存在，开始迁移。
		if(FileManager.FileExists(*PackageFullPath))
		{
			FString DestinationFullPath = FPaths::Combine(DestinationPath,RelativePath);
			DestinationFullPath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);

			//如果该位置未存在文件,直接考过去, 若已存在,保存,循环结束后根据用户选择是否替换
			if(!FileManager.FileExists(*DestinationFullPath))
			{
				FileManager.Copy(*DestinationFullPath,*PackageFullPath);
				HasFileMoved = true;
			}
			else
			{
				ExistingPackages.Add(DestinationFullPath,PackageFullPath);
			}
		}
	}

	if(ExistingPackages.Num()>0)
	{
		FText Title = LOCTEXT("MessageTitle","Message");
		FText Message = LOCTEXT("MessageReplaceExisting","Replace existing external actors at target location?");

		if(FMessageDialog::Open(EAppMsgType::YesNo,Message,Title) == EAppReturnType::Yes)
		{
			for(const TPair<FString,FString>& ReplacePackage : ExistingPackages)
			{
				FileManager.Copy(*ReplacePackage.Key,*ReplacePackage.Value);
				HasFileMoved = true;
			}
		}
	}
	
	return HasFileMoved;
}

void MigrateActorUtils::GetActorsReferencedAssets(TArray<FName>& AssetsList, TWeakObjectPtr<AActor> Actor)
{
	TArray<UObject*> ReferencedObjects;
	Actor->GetReferencedContentObjects(ReferencedObjects);
					
	for(const UObject* Object : ReferencedObjects)
	{
		if(Object->IsAsset() && Object->GetPathName().StartsWith("/Game/"))
		{
			FAssetData ObjectAsset(Object);
			AssetsList.AddUnique(ObjectAsset.PackageName);
		}
	}
}

void MigrateActorUtils::AddActorsLocatedFoldersToList(TArray<FName>& PackageNamesList, TWeakObjectPtr<AActor> Actor)
{
	if(!Actor->GetFolderPath().IsNone())
	{
		FFolder ActorFolder = Actor->GetFolder();
		PackageNamesList.AddUnique(FName(ActorFolder.GetActorFolder()->GetPackage()->GetName()));
		//直到没有父级文件夹
		while (!ActorFolder.GetParent().IsNone())
		{
			ActorFolder = ActorFolder.GetParent();
			PackageNamesList.AddUnique(FName(ActorFolder.GetActorFolder()->GetPackage()->GetName()));
		}
	}
}

#if BETA
void MigrateActorUtils::SynFromContentWhenLevelClosed(const FString& LevelAssetPackageName)
{
	//1. 开启窗口,选择content
	FString SynFolderName;
	if(!OpenSelectFolderDialog(SynFolderName, LOCTEXT("SynFromFolderTitle", "Choose a resource Content folder").ToString())) return;

	FString LevelAssetPackageNameNoGame = LevelAssetPackageName;
	LevelAssetPackageNameNoGame.RemoveFromStart("/Game");
	//加/,否则不能startwith, 因为map1也startwith - map
	LevelAssetPackageNameNoGame.AppendChar(*TEXT("/"));
	
	//2. 找到content中外部actor和外部object中该关卡, 移入本项目
	IFileManager& FileManager = IFileManager::Get();
	//需要遍历关卡文件夹并逐项移动
	const FString AbsoluteProjectContentDir = FileManager.ConvertToAbsolutePathForExternalAppForRead(*FPaths::ProjectContentDir());

	//该关卡是否有内容更新
	bool HasLevelExternalPackageUpdate = false;
	//遍历文件夹中是否存在普通资产, 记录
	bool HasAssetInContent = false;
	//TArray<FString> AssetsList;

	//bsuccess用于标识是否遍历完成, 以进行下一步
	const bool bSuccess = FileManager.IterateDirectoryRecursively(*SynFolderName,[&](const TCHAR* FilenameOrDirectory, bool bIsDirectory)
	{
		if(!bIsDirectory)
		{
			//1. 与关卡路径比较, 是该关卡再操作
			FString Filename = FilenameOrDirectory;
			int FileType = 0;/*0: 普通content资产. 1: ExternalActors 2: ExternalObjects*/
			//获取到content后关卡路径
			if(const int32 IndexA = Filename.Find("/__ExternalActors__/"); IndexA >= 0 /*必须判断>=0, 如果是-1,if判断为true*/)
			{
				Filename = Filename.RightChop(IndexA+19/*FString("/__ExternalActors__").Len()*/);
				FileType = 1;
			}
			else if(const int32 IndexO = Filename.Find("/__ExternalObjects__/"); IndexO >= 0)
			{
				Filename = Filename.RightChop(IndexO+20);
				FileType = 2;
			}
			else
			{
				//找到普通资产, 记录
				HasAssetInContent = true;
				//AssetsList.AddUnique(FilenameOrDirectory);
			}
			
			//a.是当前关卡,b.不是普通资产.与右键的关卡对比, 是的话操作复制. 
			if(Filename.StartsWith(LevelAssetPackageNameNoGame) && FileType!=0)
			{
				HasLevelExternalPackageUpdate = true;
				//2. 与项目路径结合,生成目标路径
				FString DestinationPath;
				if(FileType == 1)
				{
					DestinationPath = FPaths::Combine(AbsoluteProjectContentDir,"__ExternalActors__",Filename);
				}
				else if(FileType == 2)
				{
					DestinationPath = FPaths::Combine(AbsoluteProjectContentDir,"__ExternalObjects__",Filename);
				}
				//在拷贝时,"/"会识别不了,忘了怎么排查的了, 改为"\\"
				DestinationPath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
				//3. copy
				//todo: 不行, 无法修改自身项目内资产
				FileManager.Copy(*DestinationPath,FilenameOrDirectory);
			}
		}
		//这里必须返回true才会继续遍历,返回false直接退出, 并最终返回给success的结果
		return true;
	});
	
	if(bSuccess)
	{
		//3.todo: 这里继续进行删除操作
		//FString DeletedActorList = SynFolderName;
		//DeletedActorList.Append("\\Saved\\MigrateActorsRecord\\DeletedActorList.json");

		/*if(IFileManager::Get().FileExists(*DeletedActorList))
		{
			FString JsonString;
			TSharedPtr<FJsonObject> JsonObject;
			if(FFileHelper::LoadFileToString(JsonString,*DeletedActorList))
			{
				TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(JsonString);
				FJsonSerializer::Deserialize(JsonReader, JsonObject);

				if(JsonObject->HasField(LevelAssetPackageName))
				{
					for(TSharedPtr<FJsonValue> ActorPackage: JsonObject->GetArrayField(LevelAssetPackageName))
					{
						//Debug::Print(ActorPackage->AsString());
						//AbsoluteProjectContentDir
						FString ProjectActorExternalPath = FPaths::Combine(AbsoluteProjectContentDir,ActorPackage->AsString());
						
						ProjectActorExternalPath.ReplaceInline(TEXT("//"), TEXT("/"), ESearchCase::CaseSensitive);
						ProjectActorExternalPath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);


						//todo: 同步删除,无法删除项目内的uasset文件， 项目外的可以。 查看 保存关卡时引擎如何清理uass的
						ProjectActorExternalPath = "D:\\Users\\lurongjiu\\Desktop\\xx\\4KW5CG3HCUC9ODIV83ZP8U.uasset";
					
						IFileManager::Get().Copy(*FString("D:\\Users\\lurongjiu\\Desktop\\MEA54\\Content\\__ExternalActors__\\New3\\F\\1H\\4KW5CG3HCUC9ODIV83ZP8U.uasset"),*ProjectActorExternalPath);
						
						
						
						//IFileManager::Get().Delete(*ProjectActorExternalPath);
							
						{
							Debug::Print("DELETED");
							HasLevelExternalPackageUpdate = true;
						}
					}
				}
			}
		}*/
		
		//关卡更新且目录存在普通资产, 提示是否迁进来
		//4.todo:提示关卡已更新,或未改动,不弹窗, 使用右下角小提示
		if(HasLevelExternalPackageUpdate)
		{
			if(HasAssetInContent)
			{
				//todo: 因为有提示内容, 改为窗口
				FNotificationInfo Info(LOCTEXT("InfoSuccess", "Level updated. Please ensure that all other assets in content are migrated, as actors may depend on them."));
				Info.FadeOutDuration = 10.f;
				FSlateNotificationManager::Get().AddNotification(Info);
			}
			else
			{
				FNotificationInfo Info(LOCTEXT("InfoSuccessSimple", "Level updated."));
				Info.FadeOutDuration = 5.f;
				FSlateNotificationManager::Get().AddNotification(Info);
			}
		}
		else
		{
			FNotificationInfo Info(LOCTEXT("InfoNoUpdate", "This level has no updated actors"));
			Info.FadeOutDuration = 5.f;
			FSlateNotificationManager::Get().AddNotification(Info);
		}
	}
}
#endif

void MigrateActorUtils::ToggleRecorderState()
{
	MigrateActorsProperties::bIsRecording = !MigrateActorsProperties::bIsRecording;
}

bool MigrateActorUtils::GetRecorderState()
{
	return MigrateActorsProperties::bIsRecording;
}

void MigrateActorUtils::ClearLevelDeletedActorsList()
{
	if(MigrateActorsProperties::LevelDeletedActorsList.IsEmpty()) return;
	
	MigrateActorsProperties::LevelDeletedActorsList.Empty();
}

void MigrateActorUtils::DeletedActorAddToList(const AActor* ActorDeleted)
{
	//根据actor所在level判断而非持久关卡，固每个actor都要判断（是否开启了external actors）
	if(const ULevel* ActorLevel = ActorDeleted->GetLevel(); ActorLevel->IsUsingExternalActors())
	{
		if(!ActorLevel->IsTemplate() && !IsActorInTempMap(ActorDeleted))
		{
			FString ExternalActorName = ActorDeleted->GetExternalPackage()->GetName();
			ExternalActorName.RemoveFromStart("/Game");
			ExternalActorName += ".uasset";
			
			
			FString LevelName = ActorLevel->GetPackage()->GetName();
			
			if(!MigrateActorsProperties::LevelDeletedActorsList.Contains(LevelName))
			{
				MigrateActorsProperties::LevelDeletedActorsList.Add(LevelName,TArray<FString>());
			}
			MigrateActorsProperties::LevelDeletedActorsList.FindChecked(LevelName).AddUnique(ExternalActorName);
			
		}
		else
		{
			//提示:模板中删除actors不会被记录
			FNotificationInfo Info(LOCTEXT("RecorderUnsuccess_Record", "Deleting an actor in a template will not be recorded."));
			Info.FadeOutDuration = 5.f;
			FSlateNotificationManager::Get().AddNotification(Info);
		}
	}
	else
	{
		//提示:需要开启ExternalActors才会记录删除
		FNotificationInfo Info(LOCTEXT("RecorderUnsuccess_External", "Only when level UseExternalActors are enabled will the deletion be recorded."));
		Info.FadeOutDuration = 5.f;
		FSlateNotificationManager::Get().AddNotification(Info);
	}
}

bool MigrateActorUtils::DeletedActorListAddToJson()
{
	//弹窗选择路径
	bool HasAddToJson = false;
	
	if(MigrateActorsProperties::LevelDeletedActorsList.Num()>0)
	{
		FString SynFolderName;
		if(OpenSelectFolderDialog(SynFolderName, LOCTEXT("MigrateToFolderTitle", "Choose a destination Content folder").ToString()))
		{
#if BETA
			/*SynFolderName.Append("\\Saved\\MigrateActorsRecord\\DeletedActorList.json");
			
			FString JsonString;
			// 创建一个FJsonObject作为JSON结构的根
			TSharedPtr<FJsonObject> JsonObject;

			//todo： 读： 文件存在 - 读取内容到string - string反序列化JsonObject
			//todo： 写： 内容写到JsonObject - JsonObject序列化为string - string写入文件
			if(IFileManager::Get().FileExists(*SynFolderName))
			{
				if(FFileHelper::LoadFileToString(JsonString,*SynFolderName))
				{
					//FArchive* PresetFileReader = IFileManager::Get().CreateFileReader(*SynFolderName);
					TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(JsonString);
					
					FJsonSerializer::Deserialize(JsonReader, JsonObject);
				}
			}
			else
			{
				JsonObject = MakeShared<FJsonObject>(FJsonObject());
			}
			
			// 遍历TMap并填充JSON对象
			for(auto It = MigrateActorsProperties::LevelDeletedActorsList.CreateConstIterator(); It; ++It)
			{
				// 为每个键创建一个FJsonArray
				TArray<TSharedPtr<FJsonValue>> ActorsArray;
				if(JsonObject->HasField(It.Key()))
				{
					ActorsArray = JsonObject->GetArrayField(It.Key());
				}
				for(auto ActorPackage : It.Value())
				{
					ActorsArray.AddUnique(MakeShared<FJsonValueString>(ActorPackage));
				}
				JsonObject->SetArrayField(It.Key(),ActorsArray);
			}
			
			// 序列化FJsonObject为JSON字符串
			//JsonString二次利用， 之前用来读出来， 现在用来写，若已有内容， 覆盖
			
			TSharedRef<TJsonWriter<>> JsonWriter = TJsonWriterFactory<>::Create(&JsonString);
			
			FJsonSerializer::Serialize(JsonObject.ToSharedRef(), JsonWriter);
			//Debug::Print(JsonString);
			
			if(FFileHelper::SaveStringToFile(JsonString,*SynFolderName))
			{
				HasAddToJson = true;
			}*/
#endif
			
			FString JsonString;
			TSharedRef<TJsonWriter<>> JsonWriter = TJsonWriterFactory<>::Create(&JsonString);
			
			FJsonSerializer::Serialize(MakeShared<FJsonObject>(FJsonObject()), JsonWriter);
			
			for(auto It = MigrateActorsProperties::LevelDeletedActorsList.CreateConstIterator(); It; ++It)
			{
				for(auto ActorPackage : It.Value())
				{
					FString SaveFilePath = SynFolderName + ActorPackage;
					SaveFilePath.ReplaceInline(TEXT("/"), TEXT("\\"), ESearchCase::CaseSensitive);
					
					FFileHelper::SaveStringToFile(JsonString,*SaveFilePath);
					HasAddToJson = true;
				}
			}
		}
	}
	
	return HasAddToJson;
}


#undef LOCTEXT_NAMESPACE